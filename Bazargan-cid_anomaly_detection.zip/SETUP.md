# Setup Guide - Bazargan-CID

## Quick Start

### 1. Clone Repository
```bash
git clone https://github.com/YOUR_USERNAME/Bazargan-cid.git
cd Bazargan-cid
```

### 2. Create Virtual Environment
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# macOS/Linux
python3 -m venv venv
source venv/bin/activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Configure AWS (Optional, for LLM features)
```bash
# Set environment variables
export AWS_ACCESS_KEY_ID=your_key
export AWS_SECRET_ACCESS_KEY=your_secret
export AWS_DEFAULT_REGION=us-east-1

# Or configure ~/.aws/credentials
[default]
aws_access_key_id = your_key
aws_secret_access_key = your_secret
region = us-east-1
```

### 5. Run Notebook
```bash
jupyter notebook hybrid_anomaly_detection_poc.ipynb
```

## Troubleshooting

### ModuleNotFoundError
```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### TensorFlow Issues
```bash
pip install --upgrade tensorflow
```

### AWS Bedrock Not Available
- Check AWS credentials: `aws sts get-caller-identity`
- Verify model access in AWS Console → Bedrock → Model Access
- The notebook will continue with fallback narratives if unavailable

### Memory Issues
- Reduce `n_transactions` in Config (default: 1000)
- Reduce `shap_background_size` (default: 100)

## Project Structure

```
Bazargan-cid/
├── hybrid_anomaly_detection_poc.ipynb    # Main notebook
├── README.md                              # Project overview
├── SETUP.md                               # This file
├── requirements.txt                       # Python dependencies
├── LICENSE                                # MIT License
├── CONTRIBUTING.md                        # Contribution guidelines
├── .gitignore                             # Git ignore rules
├── data/                                  # Data directory (created on first run)
│   └── transactions.csv                   # Synthetic data cache
└── .kiro/specs/                           # Specification documents
    └── hybrid-anomaly-detection-poc/
        ├── requirements.md                # Detailed requirements
        ├── design.md                      # Technical design
        └── tasks.md                       # Implementation tasks
```

## Next Steps

1. Read `README.md` for project overview
2. Open `hybrid_anomaly_detection_poc.ipynb` in Jupyter
3. Run all cells (Kernel → Restart & Run All)
4. Explore the results and visualizations

## Support

For issues or questions:
- Check existing GitHub Issues
- Create a new Issue with details
- Include error messages and environment info

---

**Happy exploring!** 🚀
