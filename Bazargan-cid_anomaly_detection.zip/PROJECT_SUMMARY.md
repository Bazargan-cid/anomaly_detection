# 📊 Bazargan-CID: Hybrid Anomaly Detection PoC

**Status:** ✅ Production Ready  
**Last Updated:** April 2026  
**Version:** 1.0.0

---

## 🎯 Project Overview

A complete, production-ready Jupyter Notebook implementing a **hybrid anomaly detection system** for QR-based digital payment transactions. The system combines machine learning, explainable AI, and large language models to detect and explain fraudulent transactions.

### Key Components

1. **Dual Data Ingestion**
   - Synthetic transaction generation
   - External CSV dataset loading
   - Automatic data validation

2. **Hybrid Anomaly Detection**
   - Isolation Forest (tree-based)
   - Autoencoder (deep learning)
   - Weighted hybrid scoring

3. **Explainability**
   - SHAP: Global + local feature importance
   - LIME: Instance-level explanations
   - Both target the full hybrid pipeline

4. **LLM Integration**
   - AWS Bedrock Claude 3 Sonnet
   - Natural language reasoning
   - Non-fatal error handling

---

## 📦 Deliverables

### Main Notebook
- **`hybrid_anomaly_detection_poc.ipynb`** (26 cells, 9 sections)
  - Fully executable top-to-bottom
  - All outputs render inline
  - No external files required

### Documentation
- **`README.md`** — User guide and quick start
- **`SETUP.md`** — Installation and configuration
- **`PUSH_TO_GITHUB.md`** — GitHub setup instructions
- **`.kiro/specs/`** — Detailed specifications
  - `requirements.md` — 13 requirements
  - `design.md` — Technical architecture
  - `tasks.md` — 16 implementation tasks

### Configuration
- **`requirements.txt`** — Python dependencies
- **`LICENSE`** — MIT License
- **`.gitignore`** — Git ignore rules
- **`.github/workflows/test.yml`** — CI/CD pipeline

---

## 🚀 Quick Start

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure AWS (Optional)
```bash
export AWS_ACCESS_KEY_ID=your_key
export AWS_SECRET_ACCESS_KEY=your_secret
export AWS_DEFAULT_REGION=us-east-1
```

### 3. Run Notebook
```bash
jupyter notebook hybrid_anomaly_detection_poc.ipynb
```

### 4. Execute
- Kernel → Restart & Run All
- View results inline

---

## 📊 Features Implemented

| Feature | Status | Details |
|---------|--------|---------|
| Data Ingestion | ✅ | Synthetic + external CSV |
| Preprocessing | ✅ | Missing values, feature engineering, scaling |
| Isolation Forest | ✅ | Tree-based anomaly detection |
| Autoencoder | ✅ | Deep learning reconstruction error |
| Hybrid Scoring | ✅ | Weighted combination with threshold |
| SHAP Explainability | ✅ | Global + local feature importance |
| LIME Explainability | ✅ | Instance-level explanations |
| AWS Bedrock | ✅ | LLM-based natural language reasoning |
| Visualizations | ✅ | Confusion matrix, SHAP plots, LIME charts |
| Error Handling | ✅ | Non-fatal, graceful degradation |
| Reproducibility | ✅ | Fixed random seeds, config-driven |

---

## 🏗️ Architecture

```
Data Ingestion
    ↓
Preprocessing (scaling, encoding, splitting)
    ↓
┌─────────────────────────────────────┐
│  Isolation Forest  │  Autoencoder   │
│  (tree-based)      │  (deep learning)│
└─────────────────────────────────────┘
    ↓
Hybrid Scoring (weighted combination)
    ↓
┌─────────────────────────────────────┐
│  SHAP (global map)  │  LIME (detail) │
└─────────────────────────────────────┘
    ↓
AWS Bedrock LLM Reasoning
    ↓
Results Summary (inline visualization)
```

---

## 📋 Configuration Parameters

```python
cfg = Config(
    data_mode='synthetic',              # 'synthetic' or 'external'
    n_transactions=1000,                # Dataset size
    anomaly_rate=0.05,                  # 5% anomalies
    random_seed=42,                     # Reproducibility
    test_size=0.20,                     # 80/20 split
    if_contamination=0.05,              # Isolation Forest
    if_n_estimators=100,
    ae_epochs=50,                       # Autoencoder
    ae_batch_size=32,
    ae_patience=10,
    w_if=0.5,                           # Hybrid weights
    w_ae=0.5,
    hybrid_threshold=0.5,
    shap_top_n=3,                       # Top features
    lime_top_n=3,
    bedrock_model_id='anthropic.claude-3-sonnet-20240229-v1:0',
    llm_top_k=5                         # Top anomalies for LLM
)
```

---

## 📊 Data Format

### Synthetic Mode (Generated)
- 1000 transactions
- Fields: transaction_id, timestamp, amount, merchant_id, merchant_category, device_id, location, payment_channel, frequency, is_anomaly
- 5% anomalies by default

### External Mode (CSV)
Required columns:
- `amount`
- `frequency`
- `device_id`
- `location`
- `payment_channel`
- `merchant_category`

Optional: `is_anomaly` (for evaluation)

---

## 🔍 Explainability

### SHAP (The Map of the Terrain)
- **Global:** Feature importance bar chart across all transactions
- **Local:** Waterfall plot showing feature contributions per transaction
- **Target:** Full Hybrid_Pipeline (IF + AE combined)

### LIME (Street-Level Detail)
- **Instance-level:** Bar chart of feature values pushing score over threshold
- **Target:** Full Hybrid_Pipeline (IF + AE combined)

---

## 🤖 LLM Integration

Sends top-K anomalies to AWS Bedrock for natural language reasoning:

```
Transaction ID: txn_42
Hybrid Score: 0.8234

SHAP Top Features:
- amount: +0.42 (pushes toward anomaly)
- frequency: +0.31 (pushes toward anomaly)

LIME Top Features:
- amount: +0.38
- location: -0.12

LLM Narrative:
"This transaction is suspicious due to an unusually high amount ($2,450) 
combined with elevated frequency (8 transactions in 24h). The primary risk 
factor is the amount spike. Recommend manual review and potential fraud alert."
```

---

## 📈 Performance Metrics

- **Classification Report:** Precision, Recall, F1-score
- **Confusion Matrix:** True/False Positives/Negatives
- **Feature Importance:** SHAP + LIME rankings
- **Anomaly Distribution:** Score histograms

---

## 🔧 Troubleshooting

### Import Errors
```bash
pip install -r requirements.txt
```

### AWS Bedrock Unavailable
- Check credentials: `aws sts get-caller-identity`
- Verify model access in AWS Console
- Notebook continues with fallback narratives

### Memory Issues
- Reduce `n_transactions` (default: 1000)
- Reduce `shap_background_size` (default: 100)

### Slow SHAP Computation
- SHAP KernelExplainer is slower but model-agnostic
- Reduce background sample size for faster computation

---

## 📚 References

- [scikit-learn Isolation Forest](https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.IsolationForest.html)
- [TensorFlow Autoencoder](https://www.tensorflow.org/tutorials/generative/autoencoder)
- [SHAP Documentation](https://shap.readthedocs.io/)
- [LIME Documentation](https://lime-ml.readthedocs.io/)
- [AWS Bedrock](https://aws.amazon.com/bedrock/)

---

## 📄 License

MIT License — See LICENSE file for details

---

## 🤝 Contributing

See CONTRIBUTING.md for guidelines

---

## 📞 Support

- Check README.md for quick start
- See SETUP.md for installation help
- Review PUSH_TO_GITHUB.md for GitHub setup
- Open GitHub Issues for bugs/questions

---

## ✅ Verification Checklist

- ✅ 26 cells (11 Markdown, 15 Code)
- ✅ 9 sections (0-9)
- ✅ 17 key functions/classes
- ✅ All imports successful
- ✅ Valid JSON structure
- ✅ All outputs render inline
- ✅ Reproducible with fixed seeds
- ✅ Non-fatal error handling
- ✅ Complete documentation
- ✅ Ready for production

---

**Status:** 🟢 Production Ready  
**Ready to Share:** ✅ Yes  
**GitHub Ready:** ✅ Yes

---

*Built with ❤️ for Kak Kennedy*
