# Requirements Document

## Introduction

This document defines the requirements for a Proof of Concept (POC) system that detects anomalous QR-based digital payment transactions using a hybrid unsupervised machine learning approach. The system supports both synthetic data generation and loading of external CSV datasets. It combines an Isolation Forest and an Autoencoder Neural Network to produce a hybrid anomaly score, then applies two complementary Explainable AI techniques: SHAP, which acts like a map of the entire terrain — providing global and local feature contributions across the full hybrid prediction pipeline — and LIME, which acts like street-level detail, delivering precise instance-level explanations for each individual anomalous transaction. Finally, it uses AWS Bedrock to generate human-readable natural language reasoning for each flagged transaction. The deliverable is a single, fully executable Jupyter Notebook that renders all visual outputs (confusion matrix, SHAP plots, LIME plots) and LLM reasoning directly inside notebook cells.

> **Revision history:** Updated per feedback from Kak Kennedy (April 2026) — added external CSV dataset support, expanded feature schema, changed SHAP target to hybrid pipeline, and clarified deliverable as a fully executable notebook with inline visual and LLM outputs.

---

## Glossary

| Term | Definition |
|---|---|
| **System** | The full POC pipeline implemented in the Jupyter Notebook. |
| **Transaction** | A single QR-based digital payment record containing timestamp, amount, device_id, location, payment_channel, merchant_category, merchant_id, and transaction frequency. |
| **Dataset** | The collection of Transaction records (synthetic or loaded from an external CSV) used for training and evaluation. |
| **Synthetic_Dataset** | A Dataset generated programmatically by the Simulator component. |
| **External_Dataset** | A Dataset loaded from a user-supplied CSV file at a configurable path. |
| **Isolation_Forest** | The scikit-learn Isolation Forest model used as the first anomaly detector. |
| **Autoencoder** | The TensorFlow/Keras neural network model used as the second anomaly detector based on reconstruction error. |
| **Hybrid_Score** | The combined anomaly score derived from the Isolation_Forest score and the Autoencoder reconstruction error, normalised to [0, 1]. |
| **Hybrid_Pipeline** | The end-to-end prediction pipeline combining Isolation_Forest and Autoencoder into a single scoring function, used as the SHAP explainability target. |
| **Anomaly_Classifier** | The component that applies a threshold to the Hybrid_Score to label a Transaction as normal or anomalous. |
| **SHAP_Explainer** | The SHAP-based component that computes global and local feature contribution values targeting the Hybrid_Pipeline. |
| **LIME_Explainer** | The LIME LimeTabularExplainer-based component that generates instance-level explanations for individual anomalous Transactions. |
| **LLM_Reasoner** | The component that sends structured prompts to AWS Bedrock and returns natural language explanations. |
| **Bedrock_Client** | The boto3 AWS Bedrock Runtime API client used by the LLM_Reasoner. |
| **Prompt** | The structured text payload sent to the LLM_Reasoner containing anomaly score, feature importances, and Transaction metadata. |
| **Explanation** | The natural language text returned by the LLM_Reasoner describing why a Transaction is anomalous. |
| **Notebook** | The single Jupyter Notebook (.ipynb) file that implements the full pipeline and renders all outputs inline. |
| **Preprocessor** | The component responsible for missing value handling, feature engineering, feature scaling, and dataset splitting. |
| **Config** | A single Python dataclass declared at the top of the Notebook containing all tuneable parameters. |

---

## Functional Requirements

### Requirement 1: Transaction Data Ingestion

**User Story:** As a data scientist, I want the system to support both synthetic data generation and loading of an external CSV dataset, so that the POC can be demonstrated with simulated data or validated against real transaction data.

#### Acceptance Criteria

1. THE System SHALL support two data ingestion modes, selectable via the Config: `"synthetic"` (generate programmatically) and `"external"` (load from a user-supplied CSV file path).
2. WHEN the ingestion mode is `"synthetic"`, THE System SHALL generate a Dataset containing at minimum 1,000 Transaction records.
3. WHEN the ingestion mode is `"external"`, THE System SHALL load the Dataset from the CSV file path specified in the Config parameter `external_dataset_path`.
4. WHEN the ingestion mode is `"external"` and the specified CSV file does not exist, THE System SHALL raise a `FileNotFoundError` with a descriptive message and halt execution.
5. WHEN generating the Dataset in `"synthetic"` mode, THE System SHALL include the following fields for each Transaction: `transaction_id` (UUID), `timestamp` (datetime), `amount` (float, USD), `merchant_id` (categorical), `merchant_category` (categorical), `device_id` (categorical), `location` (categorical), `payment_channel` (categorical), `frequency` (int, transactions in last 24 h), and `is_anomaly` (ground-truth label 0 or 1).
6. WHEN loading an External_Dataset in `"external"` mode, THE System SHALL validate that the CSV contains at minimum the following required columns: `amount`, `frequency`, `device_id`, `location`, `payment_channel`, `merchant_category`; IF any required column is missing, THE System SHALL raise a `ValueError` listing the missing columns.
7. THE System SHALL simulate normal transactions with `amount` drawn from a log-normal distribution and `frequency` drawn from a Poisson distribution (λ=3).
8. THE System SHALL inject a configurable proportion of anomalous Transaction records into the Synthetic_Dataset to simulate fraud patterns (high-value amounts or frequency spikes), with a default anomaly rate of 5%.
9. WHEN the ingestion mode is `"synthetic"`, THE System SHALL export the generated Dataset to a CSV file at `./data/transactions.csv`; WHEN that file already exists on disk, THE System SHALL load it instead of regenerating it.

---

### Requirement 2: Data Preprocessing

**User Story:** As a data scientist, I want the raw transaction data to be cleaned and prepared before model training, so that the models receive well-formed, scaled input features regardless of whether the data is synthetic or external.

#### Acceptance Criteria

1. WHEN the Dataset contains records with missing values in `amount`, `frequency`, `device_id`, `location`, `payment_channel`, or `merchant_category`, THE Preprocessor SHALL drop those records and log the count of affected rows.
2. WHEN the Dataset contains a `timestamp` field, THE Preprocessor SHALL engineer `hour_of_day` and `day_of_week` features from it; WHEN `timestamp` is absent (e.g. in some external datasets), THE Preprocessor SHALL skip this step without error.
3. THE Preprocessor SHALL one-hot encode all categorical fields (`merchant_id` if present, `merchant_category`, `device_id`, `location`, `payment_channel`), dropping the first category for each to avoid multicollinearity.
4. THE Preprocessor SHALL apply `StandardScaler` to all numeric features (`amount`, `frequency`, and any engineered numeric features), fitting the scaler exclusively on the training set and applying the same fitted scaler to transform the test set.
5. THE Preprocessor SHALL split the Dataset into a training set and a test set using a configurable ratio, with a default split of 80% training and 20% testing.
6. WHEN preprocessing is complete, THE Preprocessor SHALL print the shape of the training set and test set to the Notebook output cell.

---

### Requirement 3: Isolation Forest Anomaly Detection

**User Story:** As a data scientist, I want an Isolation Forest model to score each transaction, so that I have a tree-based anomaly signal as the first component of the hybrid detector.

#### Acceptance Criteria

1. THE Isolation_Forest SHALL be trained exclusively on the training set produced by the Preprocessor.
2. WHEN the Isolation_Forest is applied to a Transaction, THE Isolation_Forest SHALL produce a numeric anomaly score via `score_samples()`, where more negative values indicate higher anomaly likelihood.
3. THE Isolation_Forest SHALL expose a configurable `contamination` parameter that controls the expected proportion of anomalies, defaulting to the same value as `anomaly_rate` in the Config.
4. THE Isolation_Forest SHALL use a configurable `n_estimators` parameter, defaulting to 100.
5. WHEN Isolation_Forest training is complete, THE System SHALL log the number of transactions flagged as anomalous on the test set.

---

### Requirement 4: Autoencoder Anomaly Detection

**User Story:** As a data scientist, I want an Autoencoder neural network to score each transaction by reconstruction error, so that I have a deep-learning-based anomaly signal as the second component of the hybrid detector.

#### Acceptance Criteria

1. THE Autoencoder SHALL be trained exclusively on the subset of the training set where `y_train == 0` (normal transactions only).
2. WHEN the Autoencoder processes a Transaction, THE Autoencoder SHALL compute a per-sample Mean Squared Error (MSE) between the input and the reconstructed output as its anomaly score.
3. THE Autoencoder architecture SHALL follow an encoder–bottleneck–decoder structure: Input(D) → Dense(D//2, ReLU) → Dense(D//4, ReLU) → Dense(max(D//8, 4), ReLU) → Dense(D//4, ReLU) → Dense(D//2, ReLU) → Dense(D, Linear).
4. THE Autoencoder SHALL be compiled with the Adam optimizer (learning rate 1e-3) and MSE loss.
5. THE Autoencoder SHALL be trained for a configurable number of epochs with a configurable batch size, defaulting to 50 epochs and batch size 32.
6. THE Autoencoder SHALL use early stopping with a configurable patience (default 10 epochs), monitoring `val_loss`, and restoring the best weights on stop.
7. WHEN Autoencoder training is complete, THE System SHALL plot the training and validation loss curve in the Notebook output.

---

### Requirement 5: Hybrid Anomaly Score and Classification

**User Story:** As a data scientist, I want the anomaly scores from both models to be combined into a single hybrid score, so that the final anomaly classification benefits from both detection approaches.

#### Acceptance Criteria

1. THE Anomaly_Classifier SHALL invert the Isolation_Forest `score_samples` output (multiply by -1) so that higher values indicate higher anomaly likelihood.
2. THE Anomaly_Classifier SHALL min-max normalise both the inverted Isolation_Forest score and the Autoencoder MSE reconstruction error independently to the range [0, 1].
3. THE Anomaly_Classifier SHALL compute the Hybrid_Score as a weighted average: `hybrid = w_if * if_norm + w_ae * ae_norm`, with configurable weights defaulting to 0.5 each, where `w_if + w_ae == 1.0`.
4. WHEN the Hybrid_Score for a Transaction meets or exceeds a configurable threshold (default 0.5), THE Anomaly_Classifier SHALL label that Transaction as anomalous (label = 1).
5. THE Anomaly_Classifier SHALL output a classification report including precision, recall, and F1-score for the anomalous class on the test set.
6. THE Anomaly_Classifier SHALL produce a confusion matrix heatmap visualization in the Notebook output.

---

### Requirement 6: SHAP Explainability

**User Story:** As a data scientist, I want SHAP values computed for the full hybrid prediction pipeline, so that I can understand which features drive the combined anomaly score both globally and for individual transactions.

#### Acceptance Criteria

1. THE SHAP_Explainer SHALL target the Hybrid_Pipeline (the combined Isolation Forest + Autoencoder scoring function) as its explainability subject, not the Isolation Forest model in isolation.
2. THE SHAP_Explainer SHALL use `shap.KernelExplainer` or `shap.Explainer` with the `hybrid_predict_fn` wrapper as the model function, so that SHAP values reflect the contribution of each feature to the final Hybrid_Score.
3. THE SHAP_Explainer SHALL compute global feature importance values across all test set Transactions and display a `shap.summary_plot` bar chart in the Notebook output cell.
4. WHEN a Transaction is classified as anomalous, THE SHAP_Explainer SHALL compute local SHAP values for that Transaction and display a waterfall or force plot directly in the Notebook output cell.
5. WHEN SHAP computation is complete, THE SHAP_Explainer SHALL extract and return the top-N contributing features and their SHAP values for each anomalous Transaction, where N is configurable with a default of 3.

---

### Requirement 7: LIME Explainability

**User Story:** As a data scientist, I want LIME explanations generated for individual anomalous transactions, so that I have a model-agnostic, instance-level explanation to complement SHAP.

#### Acceptance Criteria

1. THE LIME_Explainer SHALL use `LimeTabularExplainer` initialised with the training set and feature names.
2. WHEN a Transaction is classified as anomalous, THE LIME_Explainer SHALL call `explain_instance` using a `hybrid_predict_fn` wrapper that returns `[P(normal), P(anomaly)]` for any input array.
3. THE LIME_Explainer SHALL display the feature contributions for each explained Transaction as a horizontal bar chart in the Notebook output.
4. THE LIME_Explainer SHALL extract and return the top-N contributing features and their contribution weights for each explained Transaction, where N is configurable with a default of 3.

---

### Requirement 8: LLM-Based Natural Language Reasoning

**User Story:** As a business analyst, I want a natural language explanation generated for each anomalous transaction, so that non-technical stakeholders can understand why a transaction was flagged.

#### Acceptance Criteria

1. THE LLM_Reasoner SHALL select the top-K anomalous Transactions ranked by descending Hybrid_Score, where K is configurable with a default of 5.
2. THE LLM_Reasoner SHALL construct a structured Prompt for each selected Transaction that includes: the Hybrid_Score, normalised IF and AE scores, the top SHAP feature contributions, the top LIME feature contributions, and the Transaction metadata (timestamp, amount, merchant ID, frequency).
3. WHEN a Prompt is ready, THE LLM_Reasoner SHALL invoke the Bedrock_Client using `boto3` to call the AWS Bedrock Runtime `invoke_model` API with a configurable model ID (default: `anthropic.claude-3-sonnet-20240229-v1:0`) and AWS region.
4. WHEN the Bedrock_Client receives a successful response, THE LLM_Reasoner SHALL extract the Explanation text and display it in the Notebook output alongside the corresponding Transaction record and its anomaly scores.
5. IF the Bedrock_Client call fails for any reason (credentials error, throttling, network timeout, parse error), THEN THE LLM_Reasoner SHALL log the error and set the narrative to `"LLM unavailable: <error message>"` without halting notebook execution.
6. THE LLM_Reasoner SHALL store the full Prompt sent to Bedrock alongside the Explanation for auditability.

---

### Requirement 9: Notebook Structure, Visual Outputs, and Documentation

**User Story:** As a developer or reviewer, I want the Jupyter Notebook to be fully executable top-to-bottom and render all visual and LLM outputs directly inside notebook cells, so that the pipeline is self-contained, reproducible, and presentable without any external tooling.

#### Acceptance Criteria

1. THE Notebook SHALL be organized into clearly labeled sections corresponding to each pipeline phase: (0) Setup & Config, (1) Data Ingestion, (2) Preprocessing, (3) Isolation Forest, (4) Autoencoder, (5) Hybrid Scoring, (6) SHAP Explainability, (7) LIME Explainability, (8) LLM Reasoning, (9) Results Summary.
2. THE Notebook SHALL include a Markdown cell at the beginning of each section describing the purpose, inputs, and expected outputs of that section.
3. THE Notebook SHALL include a top-level Markdown cell containing the project title, objective, technical stack summary, and a brief description of the four pipeline phases.
4. THE Notebook SHALL be fully executable from top to bottom in a single kernel run without manual intervention, assuming required dependencies are installed and AWS credentials are configured.
5. THE Notebook SHALL render the following visual outputs directly as inline cell outputs (not saved to external files): confusion matrix heatmap, SHAP global summary bar plot, SHAP local waterfall or force plot for each anomalous transaction, and LIME horizontal bar chart for each anomalous transaction.
6. THE Notebook SHALL display the LLM natural language reasoning output from AWS Bedrock directly in the notebook output cell alongside the corresponding transaction record — not in a separate file or external log.
7. THE System SHALL declare all configurable parameters in a single `Config` dataclass cell near the top of the Notebook (Section 0), including: `data_mode`, `external_dataset_path`, `n_transactions`, `anomaly_rate`, `random_seed`, `test_size`, `if_contamination`, `if_n_estimators`, `ae_epochs`, `ae_batch_size`, `ae_patience`, `w_if`, `w_ae`, `hybrid_threshold`, `shap_top_n`, `lime_top_n`, `bedrock_model_id`, `llm_top_k`.

---

## Technical / Non-Functional Requirements

### Requirement 10: Technology Stack

**User Story:** As a developer, I want the technology stack explicitly defined, so that I can set up the correct environment before implementation.

#### Acceptance Criteria

1. THE System SHALL be implemented in Python 3.9 or higher.
2. THE System SHALL use `scikit-learn` for the Isolation Forest implementation.
3. THE System SHALL use `tensorflow` (Keras API) for the Autoencoder implementation.
4. THE System SHALL use `shap` for SHAP explainability.
5. THE System SHALL use `lime` for LIME explainability.
6. THE System SHALL use `boto3` and the AWS Bedrock Runtime API for LLM reasoning.
7. THE System SHALL use `pandas` and `numpy` for data manipulation.
8. THE System SHALL use `matplotlib` and `seaborn` for all visualizations.

---

### Requirement 11: Dependency and Environment Management

**User Story:** As a developer, I want all required dependencies declared explicitly, so that the environment can be reproduced consistently.

#### Acceptance Criteria

1. THE Notebook SHALL include a Markdown cell in Section 0 listing all required Python packages and their minimum versions: `scikit-learn>=1.3`, `tensorflow>=2.13`, `shap>=0.43`, `lime>=0.2`, `boto3>=1.34`, `pandas>=2.0`, `numpy>=1.24`, `matplotlib>=3.7`, `seaborn>=0.12`.
2. THE Notebook SHALL include an optional `pip install` cell at the top that can be uncommented to install all dependencies in one command.
3. WHERE AWS credentials are required, THE System SHALL read them from environment variables (`AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `AWS_DEFAULT_REGION`) or an AWS credentials file, and SHALL NOT hardcode any credential values in the Notebook.

---

### Requirement 12: Reproducibility

**User Story:** As a data scientist, I want all random operations to use a fixed seed, so that results are reproducible across runs.

#### Acceptance Criteria

1. THE System SHALL set `random_seed` from the Config in all stochastic operations: `numpy.random.seed`, `random.seed`, `tensorflow.random.set_seed`, and the `random_state` parameter of all scikit-learn models.
2. WHEN the Dataset CSV already exists on disk, THE System SHALL produce identical model outputs across runs given the same Config values.

---

### Requirement 13: Deliverables

**User Story:** As a project stakeholder, I want clearly defined deliverables, so that I can verify the POC is complete.

#### Acceptance Criteria

1. THE project SHALL deliver one fully executable Jupyter Notebook file (`hybrid_anomaly_detection_poc.ipynb`) implementing the complete pipeline from data ingestion to LLM reasoning.
2. THE Notebook SHALL display all visual outputs (confusion matrix heatmap, SHAP plots, LIME plots) and all LLM natural language reasoning outputs as inline cell outputs — no outputs shall require opening external files.
3. WHEN run in `"synthetic"` mode, THE project SHALL also deliver the generated transaction dataset file at `./data/transactions.csv`.
4. THE Notebook SHALL serve as its own documentation, with all explanations embedded as Markdown cells — no separate documentation file is required.
