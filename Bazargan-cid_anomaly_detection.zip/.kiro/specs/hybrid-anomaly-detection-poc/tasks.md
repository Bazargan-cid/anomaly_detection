# Implementation Plan: Hybrid Anomaly Detection PoC

> **Revision:** Updated per feedback from Kak Kennedy (April 2026) — dual ingestion mode, expanded feature schema, SHAP targeting Hybrid_Pipeline, all outputs inline in notebook cells.

---

## Overview

Implement `hybrid_anomaly_detection_poc.ipynb` — a single, fully executable Jupyter Notebook covering the complete pipeline from data ingestion to inline LLM reasoning output. Tasks are ordered sequentially; each builds on the previous. Tasks marked `*` are optional (property-based tests) and can be skipped for a faster MVP.

**Role legend:**
- 🤖 **AI/Script** — implemented by the developer writing Python code in notebook cells
- 🖥️ **Platform** — environment setup, cloud configuration, or tooling done outside the notebook

**Estimated total time:** ~10–13 hours (excluding optional PBT tasks)

---

## Tasks

- [ ] 1. Environment and project scaffold
  - [ ] 1.1 🖥️ Set up Python environment and install dependencies *(~20 min)*
    - Create a virtual environment (Python 3.9+)
    - Install: `scikit-learn>=1.3 tensorflow>=2.13 shap>=0.43 lime>=0.2 boto3>=1.34 pandas>=2.0 numpy>=1.24 matplotlib>=3.7 seaborn>=0.12`
    - Verify all imports succeed in a test script
    - _Requirements: 10, 11.1_
  - [~] 1.2 🖥️ Configure AWS credentials *(~15 min)*
    - Set `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `AWS_DEFAULT_REGION` as environment variables or configure `~/.aws/credentials`
    - Verify access to AWS Bedrock Runtime in the target region
    - Confirm the model ID `anthropic.claude-3-sonnet-20240229-v1:0` is enabled in Bedrock Model Access
    - _Requirements: 11.3_
  - [~] 1.3 🤖 Create notebook skeleton with section structure *(~20 min)*
    - Create `hybrid_anomaly_detection_poc.ipynb`
    - Create directory `./data/`
    - Add one Markdown cell + one empty code cell per section: (0) Setup & Config, (1) Data Ingestion, (2) Preprocessing, (3) Isolation Forest, (4) Autoencoder, (5) Hybrid Scoring, (6) SHAP Explainability, (7) LIME Explainability, (8) LLM Reasoning, (9) Results Summary
    - Add top-level Markdown cell: project title, objective, tech stack summary, four-phase description
    - Add optional (commented-out) `pip install` cell
    - _Requirements: 9.1, 9.2, 9.3, 11.2_

- [ ] 2. Implement Config dataclass and global seed setup *(~20 min)*
  - [~] 2.1 🤖 Implement `Config` dataclass with all 19 parameters
    - Fields: `data_mode`, `external_dataset_path`, `n_transactions`, `anomaly_rate`, `random_seed`, `test_size`, `if_contamination`, `if_n_estimators`, `ae_epochs`, `ae_batch_size`, `ae_patience`, `w_if`, `w_ae`, `hybrid_threshold`, `shap_top_n`, `lime_top_n`, `shap_background_size`, `bedrock_model_id`, `llm_top_k`
    - Instantiate `cfg = Config()` immediately after the class definition
    - _Requirements: 9.7_
  - [~] 2.2 🤖 Implement global random seed initialisation
    - Call `numpy.random.seed(cfg.random_seed)`, `random.seed(cfg.random_seed)`, `tensorflow.random.set_seed(cfg.random_seed)`
    - _Requirements: 12.1_

- [ ] 3. Implement Data Ingestion (Section 1) *(~45 min)*
  - [~] 3.1 🤖 Implement `generate_transactions(n, anomaly_rate, random_seed)` for synthetic mode
    - Generate normal transactions: `amount` ~ LogNormal(μ=4.5, σ=0.8), `frequency` ~ Poisson(λ=3)
    - Generate anomalous transactions: `amount` ~ Uniform(500, 5000) OR `frequency` ~ Poisson(λ=20), randomly mixed
    - Assign fields: `transaction_id` (UUID v4), `timestamp` (UTC, 30-day window), `amount`, `merchant_id` (`"M001"`–`"M020"`), `merchant_category` (e.g. `"food"`, `"electronics"`, `"travel"`, `"retail"`, `"transport"`), `device_id` (`"D001"`–`"D050"`), `location` (e.g. `"Jakarta"`, `"Surabaya"`, `"Bali"`, `"Bandung"`), `payment_channel` (`"QR"`, `"NFC"`, `"online"`), `frequency`, `is_anomaly`
    - _Requirements: 1.2, 1.5, 1.7, 1.8_
  - [~] 3.2 🤖 Implement `_validate_columns(df)` for external mode
    - Required columns: `amount`, `frequency`, `device_id`, `location`, `payment_channel`, `merchant_category`
    - Raise `ValueError` listing all missing columns if any are absent
    - _Requirements: 1.6_
  - [~] 3.3 🤖 Implement `load_or_generate(cfg)` dispatcher
    - `"synthetic"` mode: check if `./data/transactions.csv` exists → load; else generate and save
    - `"external"` mode: check file exists → raise `FileNotFoundError` if not; load CSV; call `_validate_columns`
    - _Requirements: 1.1, 1.3, 1.4, 1.9_
  - [ ]* 3.4 🤖 Write property test for anomaly injection rate (Property 1) *(~20 min)*
    - **Property 1: Anomaly injection rate is within bounds**
    - Use `hypothesis` to generate random `(n, anomaly_rate)` pairs; assert `abs(actual_rate - anomaly_rate) < 0.01`
    - Tag: `# Feature: hybrid-anomaly-detection-poc, Property 1`
    - **Validates: Req 1.2, 1.8**

- [ ] 4. Implement Preprocessing (Section 2) *(~45 min)*
  - [~] 4.1 🤖 Define `PreprocessedData` NamedTuple
    - Fields: `X_train`, `X_test`, `y_train`, `y_test`, `scaler`, `feature_names`
    - _Requirements: 2_
  - [~] 4.2 🤖 Implement `preprocess(df, cfg)` returning `PreprocessedData`
    - Drop rows with nulls in `amount`, `frequency`, `device_id`, `location`, `payment_channel`, `merchant_category`; log count
    - Raise `ValueError("Dataset empty after cleaning")` if all rows dropped
    - If `timestamp` column exists: engineer `hour_of_day`, `day_of_week`; skip silently if absent
    - One-hot encode: `merchant_id` (if present), `merchant_category`, `device_id`, `location`, `payment_channel` — all with `drop_first=True`
    - Train/test split with `test_size` and `random_seed`; raise `ValueError` if either split < 10 samples
    - Fit `StandardScaler` on `X_train` only; transform both splits with same fitted scaler
    - Print `X_train.shape` and `X_test.shape` to output cell
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 2.6_
  - [ ]* 4.3 🤖 Write property test for scaler fit-on-train isolation (Property 2) *(~20 min)*
    - **Property 2: Scaler fit-on-train / transform-test isolation**
    - Assert `X_train` mean ≈ 0 and std ≈ 1 after scaling; assert same scaler object used for `X_test`
    - Tag: `# Feature: hybrid-anomaly-detection-poc, Property 2`
    - **Validates: Req 2.4**

- [ ] 5. ✅ Checkpoint — Data pipeline *(~10 min)*
  - Run Sections 0–2 end-to-end; verify `./data/transactions.csv` created, shapes print correctly, no errors in both `"synthetic"` and `"external"` modes (use a small test CSV for external)

- [ ] 6. Implement Isolation Forest (Section 3) *(~30 min)*
  - [~] 6.1 🤖 Implement `train_isolation_forest(X_train, contamination, n_estimators, random_seed)`
    - Instantiate `IsolationForest(contamination=contamination, n_estimators=n_estimators, random_state=random_seed)`
    - Fit on `X_train`; call `score_samples(X_test)` to produce `if_scores`
    - Log count of test-set transactions where `predict(X_test) == -1`
    - Return `(fitted_model, if_scores)`
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5_
  - [ ]* 6.2 🤖 Write unit tests for `train_isolation_forest()` *(~15 min)*
    - Assert `len(if_scores) == len(X_test)`, all scores are floats, model has `estimators_` attribute

- [ ] 7. Implement Autoencoder (Section 4) *(~60 min)*
  - [~] 7.1 🤖 Implement `Autoencoder` class with `__init__`, `fit`, `reconstruction_error`
    - `__init__`: build Keras model — Input(D) → Dense(D//2, relu) → Dense(D//4, relu) → Dense(max(D//8,4), relu) → Dense(D//4, relu) → Dense(D//2, relu) → Dense(D, linear); compile with `Adam(1e-3)`, `loss="mse"`
    - `fit(X_normal)`: train with `EarlyStopping(monitor="val_loss", patience=cfg.ae_patience, restore_best_weights=True)`, `validation_split=0.1`; return `History`
    - `reconstruction_error(X)`: return per-sample MSE as `np.ndarray`
    - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5, 4.6_
  - [~] 7.2 🤖 Wire Autoencoder training into notebook cell
    - Extract `X_train_normal = X_train[y_train == 0]`; raise `ValueError` if empty
    - Instantiate, fit, compute `ae_scores = autoencoder.reconstruction_error(X_test)`
    - _Requirements: 4.1_
  - [~] 7.3 🤖 Plot training and validation loss curve inline *(~10 min)*
    - `plt.plot(history.history["loss"], label="train")` + `plt.plot(history.history["val_loss"], label="val")`
    - Label axes, add legend, call `plt.show()` — renders inline
    - _Requirements: 4.7, 9.5_
  - [ ]* 7.4 🤖 Write property tests for Autoencoder (Properties 7 & 8) *(~25 min)*
    - **Property 7:** Assert all MSE values ≥ 0 for any input
    - **Property 8:** Assert mean error on normals < mean error on anomalies
    - Tags: `# Feature: hybrid-anomaly-detection-poc, Property 7` and `Property 8`
    - **Validates: Req 4.1, 4.2**

- [ ] 8. ✅ Checkpoint — Model training *(~10 min)*
  - Run Sections 3–4; verify IF scores array length == `len(X_test)`, AE loss plot renders inline, no training errors

- [ ] 9. Implement Hybrid Scoring (Section 5) *(~45 min)*
  - [~] 9.1 🤖 Define `AnomalyResult` dataclass
    - Fields: `transaction_id`, `if_score_raw`, `ae_score_raw`, `if_score_norm`, `ae_score_norm`, `hybrid_score`, `predicted_label`, `true_label`, `features`
    - _Requirements: 5_
  - [~] 9.2 🤖 Implement `compute_hybrid_scores(if_scores, ae_scores, w_if, w_ae, threshold)`
    - Invert IF: `s_IF_inv = -if_scores`
    - Min-max normalise both independently; handle `max == min` edge case (set to 0.0, log warning)
    - Raise `ValueError("Weights must sum to 1.0")` if `abs(w_if + w_ae - 1.0) > 1e-9`
    - Compute `hybrid = w_if * if_norm + w_ae * ae_norm`; classify with threshold
    - Return `list[AnomalyResult]`
    - _Requirements: 5.1, 5.2, 5.3, 5.4_
  - [~] 9.3 🤖 Implement `hybrid_predict_fn(X)` wrapper
    - Accepts `np.ndarray` of shape `(n_samples, n_features)`
    - Runs IF `score_samples` + AE `reconstruction_error` → normalise → weighted average
    - Returns `np.ndarray` of shape `(n_samples, 2)`: `[[P(normal), P(anomaly)], ...]`
    - This function is shared by both SHAP and LIME
    - _Requirements: 6.2, 7.2_
  - [~] 9.4 🤖 Print classification report and render confusion matrix inline *(~15 min)*
    - `sklearn.metrics.classification_report(y_test, predicted_labels)` → print
    - `seaborn.heatmap(confusion_matrix(...))` → `plt.show()` — renders inline
    - _Requirements: 5.5, 5.6, 9.5_
  - [ ]* 9.5 🤖 Write property tests for hybrid scoring (Properties 3 & 4) *(~20 min)*
    - **Property 3:** Assert all `hybrid_score` ∈ [0, 1] for any input arrays
    - **Property 4:** Assert formula holds element-wise for any weights summing to 1.0
    - Tags: `# Feature: hybrid-anomaly-detection-poc, Property 3` and `Property 4`
    - **Validates: Req 5.2, 5.3**

- [ ] 10. Implement SHAP Explainability — "the map of the terrain" (Section 6) *(~60 min)*
  - SHAP provides the global map of the Hybrid_Pipeline: which features consistently drive the hybrid anomaly score across all transactions, plus local views for each flagged transaction.
  - [~] 10.1 🤖 Define `SHAPExplanation` dataclass
    - Fields: `transaction_id`, `shap_values`, `top_features`, `base_value`
    - _Requirements: 6_
  - [~] 10.2 🤖 Implement `explain_shap(hybrid_predict_fn, X_train, X_anomalies, feature_names, top_n)`
    - Create background sample: `shap.sample(X_train, cfg.shap_background_size)`
    - Instantiate `shap.KernelExplainer(hybrid_predict_fn, background_sample)`
    - Compute SHAP values for all test-set samples: `explainer.shap_values(X_test)`
    - Render global summary bar plot inline: `shap.summary_plot(..., plot_type="bar", show=True)`
    - For each anomalous transaction: compute local SHAP values, render `shap.waterfall_plot` or `shap.force_plot` inline
    - Extract top-N features: `np.argsort(np.abs(shap_values[i]))[-top_n:]`
    - On failure for a sample: log error, set `shap_values = np.zeros(n_features)`
    - Return `list[SHAPExplanation]`
    - _Requirements: 6.1, 6.2, 6.3, 6.4, 6.5, 9.5_
  - [ ]* 10.3 🤖 Write property test for SHAP top-N count (Property 5) *(~15 min)*
    - **Property 5:** Assert `len(top_features) == min(top_n, n_features)` for any `top_n ≥ 1`
    - Tag: `# Feature: hybrid-anomaly-detection-poc, Property 5`
    - **Validates: Req 6.5**

- [ ] 11. Implement LIME Explainability — "street-level detail" (Section 7) *(~45 min)*
  - LIME provides precise instance-level explanations: for each individual anomalous transaction, which specific feature values pushed the hybrid score over the threshold. Complements SHAP's global map with granular per-transaction detail.
  - [~] 11.1 🤖 Define `LIMEExplanation` dataclass
    - Fields: `transaction_id`, `top_features`, `local_pred`
    - _Requirements: 7_
  - [~] 11.2 🤖 Implement `explain_lime(hybrid_predict_fn, X_train, X_anomaly, feature_names, top_n)`
    - Instantiate `LimeTabularExplainer(X_train, feature_names=feature_names, mode="classification")`
    - Call `explainer.explain_instance(X_anomaly, hybrid_predict_fn, num_features=top_n)`
    - Render bar chart inline: `exp.as_pyplot_figure()` → `plt.show()`
    - Extract top-N features and weights
    - On failure: log error, set `top_features = []`
    - Return `LIMEExplanation`
    - _Requirements: 7.1, 7.2, 7.3, 7.4, 9.5_
  - [ ]* 11.3 🤖 Write property test for LIME top-N count (Property 6) *(~15 min)*
    - **Property 6:** Assert `len(top_features) == min(top_n, n_features)` for any `top_n ≥ 1`
    - Tag: `# Feature: hybrid-anomaly-detection-poc, Property 6`
    - **Validates: Req 7.4**

- [ ] 12. ✅ Checkpoint — Explainability outputs *(~10 min)*
  - Run Sections 6–7; verify SHAP global bar plot, at least one SHAP local plot, and at least one LIME bar chart all render inline without error

- [ ] 13. Implement LLM Reasoning (Section 8) *(~75 min)*
  - [~] 13.1 🤖 Define `ExplanationRecord` dataclass *(~5 min)*
    - Fields: `transaction_id`, `anomaly_result`, `shap_explanation`, `lime_explanation`, `llm_narrative`, `prompt_sent`
    - _Requirements: 8.6_
  - [~] 13.2 🤖 Implement `build_prompt(anomaly_result, shap_exp, lime_exp, cfg)` *(~20 min)*
    - Populate prompt template with all Transaction metadata fields (including `merchant_category`, `device_id`, `location`, `payment_channel`)
    - Render SHAP and LIME feature lists as `"- {feature}: {value:+.2f} (pushes toward anomaly/normal)"`
    - Return formatted string
    - _Requirements: 8.2_
  - [~] 13.3 🤖 Implement `explain_with_llm(anomaly_results, shap_exps, lime_exps, cfg)` *(~30 min)*
    - Select top-K anomalies by descending `hybrid_score`
    - Instantiate `boto3.client("bedrock-runtime", region_name=os.environ["AWS_DEFAULT_REGION"])`
    - For each: call `build_prompt()`, invoke `client.invoke_model()`, parse response, store in `ExplanationRecord`
    - Display inline: print `transaction_id`, `hybrid_score`, `llm_narrative` in a readable format per record
    - _Requirements: 8.1, 8.3, 8.4, 8.6, 9.6, 11.3_
  - [~] 13.4 🤖 Implement all Bedrock error handling *(~20 min)*
    - `NoCredentialsError` → `"LLM unavailable: AWS credentials not configured"` — continue
    - `ClientError` (throttle/unavailable) → retry once after 2s; on 2nd failure set narrative to error — continue
    - Response parse error → `"LLM unavailable: response parse error"` — continue
    - Network timeout → `"LLM unavailable: network timeout"` — continue
    - _Requirements: 8.5_
  - [ ]* 13.5 🤖 Write unit tests for `explain_with_llm()` with mocked boto3 *(~20 min)*
    - Mock `boto3.client` → assert `llm_narrative` is non-empty
    - Mock `NoCredentialsError` → assert narrative starts with `"LLM unavailable:"`
    - Assert `prompt_sent` contains `transaction_id`, `hybrid_score`, and at least one SHAP feature
    - _Requirements: 8.3, 8.4, 8.5_

- [ ] 14. Implement Results Summary (Section 9) and final wiring *(~30 min)*
  - [~] 14.1 🤖 Add Results Summary cell
    - Display a `pandas` DataFrame with one row per top-K anomaly: `transaction_id`, `hybrid_score`, `if_score_norm`, `ae_score_norm`, `predicted_label`, `true_label`, `llm_narrative` (truncated to 100 chars)
    - _Requirements: 9.1_
  - [~] 14.2 🤖 Verify all outputs are inline (not saved to external files)
    - Confirm all `plt.show()` calls render inline; no `plt.savefig()` calls
    - Confirm LLM narratives print to output cells, not to log files
    - _Requirements: 9.5, 9.6, 13.2_

- [ ] 15. Polish notebook documentation *(~30 min)*
  - [~] 15.1 🤖 Update all section Markdown cells
    - Each section (0–9) must have a Markdown cell describing: purpose, inputs, expected outputs
    - _Requirements: 9.2_
  - [~] 15.2 🤖 Verify Config cell is complete and first
    - Confirm all 19 parameters are present with correct defaults
    - Confirm Config cell is the first code cell in Section 0
    - _Requirements: 9.7_
  - [~] 15.3 🤖 Add dependency Markdown cell in Section 0
    - List all packages with minimum versions
    - _Requirements: 11.1_

- [ ] 16. ✅ Final end-to-end verification *(~30 min)*
  - [~] 16.1 🖥️ Restart kernel and run all cells top-to-bottom
    - Confirm no exceptions raised
    - Confirm all plots render inline: loss curve, confusion matrix, SHAP global, SHAP local, LIME bar charts
    - Confirm LLM narratives display inline (or graceful fallback if Bedrock unavailable)
    - Confirm `./data/transactions.csv` created on first run, loaded on second run
    - _Requirements: 9.4, 13.1, 13.2_
  - [~] 16.2 🖥️ Test external mode *(~15 min)*
    - Set `cfg.data_mode = "external"` with a valid CSV → verify pipeline runs end-to-end
    - Set `cfg.data_mode = "external"` with a missing file → verify `FileNotFoundError` raised
    - Set `cfg.data_mode = "external"` with a CSV missing required columns → verify `ValueError` raised
    - _Requirements: 1.3, 1.4, 1.6_

---

## Time Estimate Summary

| Phase | Tasks | Role | Est. Time |
|---|---|---|---|
| Environment & scaffold | 1.1–1.3 | 🖥️ Platform + 🤖 AI | ~55 min |
| Config & seeds | 2.1–2.2 | 🤖 AI | ~20 min |
| Data ingestion | 3.1–3.3 | 🤖 AI | ~45 min |
| Preprocessing | 4.1–4.2 | 🤖 AI | ~45 min |
| Checkpoint 1 | 5 | 🖥️ Platform | ~10 min |
| Isolation Forest | 6.1 | 🤖 AI | ~30 min |
| Autoencoder | 7.1–7.3 | 🤖 AI | ~70 min |
| Checkpoint 2 | 8 | 🖥️ Platform | ~10 min |
| Hybrid scoring | 9.1–9.4 | 🤖 AI | ~60 min |
| SHAP explainability | 10.1–10.2 | 🤖 AI | ~60 min |
| LIME explainability | 11.1–11.2 | 🤖 AI | ~45 min |
| Checkpoint 3 | 12 | 🖥️ Platform | ~10 min |
| LLM reasoning | 13.1–13.4 | 🤖 AI + 🖥️ Platform | ~75 min |
| Results summary | 14.1–14.2 | 🤖 AI | ~30 min |
| Documentation polish | 15.1–15.3 | 🤖 AI | ~30 min |
| Final verification | 16.1–16.2 | 🖥️ Platform | ~45 min |
| **Total (required tasks)** | | | **~10.5–13 hrs** |
| Optional PBT tasks | 3.4, 4.3, 6.2, 7.4, 9.5, 10.3, 11.3, 13.5 | 🤖 AI | +~2.5 hrs |

---

## Notes

- **SHAP vs LIME roles:** SHAP = peta struktur keseluruhan (global + local view of Hybrid_Pipeline via KernelExplainer). LIME = detail nama jalan per transaksi (precise instance-level explanation via LimeTabularExplainer). Both use `hybrid_predict_fn` as the black-box target.
- **AWS Bedrock:** Ensure the model is enabled in Bedrock Model Access before running Section 8. If unavailable, the notebook continues with fallback narratives.
- **External mode:** The external CSV must contain at minimum: `amount`, `frequency`, `device_id`, `location`, `payment_channel`, `merchant_category`. The `is_anomaly` column is optional — if absent, evaluation metrics (classification report, confusion matrix) will be skipped.
- **Checkpoints (Tasks 5, 8, 12, 16)** are manual verification steps, not code tasks.
