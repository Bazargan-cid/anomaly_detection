# Design: Hybrid Anomaly Detection PoC

> **Revision:** Updated per feedback from Kak Kennedy (April 2026) — dual ingestion mode (synthetic/external), expanded feature schema (device_id, location, payment_channel, merchant_category), SHAP targeting Hybrid_Pipeline via KernelExplainer, all outputs rendered inline in notebook cells.

---

## Overview

This document describes the technical design for a single, fully executable Jupyter Notebook (`hybrid_anomaly_detection_poc.ipynb`) that detects anomalies in QR-payment transaction data using a hybrid machine-learning pipeline. The notebook supports two data ingestion modes: synthetic generation or loading from an external CSV. It combines an Isolation Forest and an Autoencoder into a Hybrid_Pipeline, explains predictions using SHAP (targeting the full hybrid pipeline) and LIME, and sends the top anomalies to AWS Bedrock for natural-language reasoning. All visual outputs and LLM narratives are rendered as inline notebook cell outputs.

### Design Goals

- **Dual ingestion** — switchable between synthetic generation and external CSV via a single Config parameter.
- **Reproducibility** — fixed random seeds, config-driven parameters, no side-effects outside the notebook directory.
- **Explainability** — SHAP acts as the map of the entire terrain: global and local feature contributions targeting the full Hybrid_Pipeline. LIME acts as street-level detail: precise instance-level explanations for each individual anomalous transaction. Every flagged transaction carries both SHAP + LIME + LLM narrative.
- **Inline outputs** — all plots and LLM text render directly in notebook cells; no external files required to view results.
- **Modularity** — each pipeline stage is a self-contained Python function or class, independently testable.
- **Safety** — AWS credentials are never hard-coded; read from environment variables or IAM role.

---

## Architecture

### High-Level Data Flow

```mermaid
flowchart TD
    A([▶ START]) --> B

    subgraph CFG["⓪ Config & Setup"]
        B["Config dataclass\n─────────────────────────\ndata_mode, external_dataset_path,\nn_transactions, anomaly_rate,\nrandom_seed, test_size,\nif_contamination, if_n_estimators,\nae_epochs, ae_batch_size, ae_patience,\nw_if, w_ae, hybrid_threshold,\nshap_top_n, lime_top_n,\nbedrock_model_id, llm_top_k"]
    end

    subgraph ING["① Data Ingestion"]
        C{"data_mode?"}
        C1["generate_transactions(n, anomaly_rate)\n→ Synthetic_Dataset (CSV)"]
        C2["load_external_dataset(path)\n→ validate required columns\n→ External_Dataset"]
        C -->|synthetic| C1
        C -->|external| C2
    end

    subgraph PRE["② Preprocessing"]
        D["handle_missing_values(df)\nfeature_engineer_timestamp(df)  [optional]\none_hot_encode_categoricals(df)\nStandardScaler.fit_transform(X_train)\nStandardScaler.transform(X_test)\n─────────────────────────\nOutputs: PreprocessedData\n(X_train, X_test, y_train, y_test,\n scaler, feature_names)"]
    end

    subgraph ISO["③ Isolation Forest"]
        E["IsolationForest(contamination, n_estimators)\n.fit(X_train)\n.score_samples(X_test) → if_scores\n─────────────────────────\nOutputs: fitted_if_model, if_scores"]
    end

    subgraph AE["④ Autoencoder"]
        F["Encoder → Bottleneck → Decoder\ntrained on X_train[y_train==0]\nMSE reconstruction error per sample\nEarlyStopping(patience=ae_patience)\n─────────────────────────\nOutputs: fitted_autoencoder, ae_scores\n[inline: training loss curve plot]"]
    end

    subgraph HYB["⑤ Hybrid Scoring"]
        G["invert if_scores → s_IF_inv\nmin-max normalise → if_norm ∈ [0,1]\nmin-max normalise ae_scores → ae_norm ∈ [0,1]\nhybrid = w_if·if_norm + w_ae·ae_norm\nclassify: hybrid ≥ threshold → anomaly\n─────────────────────────\nOutputs: AnomalyResult[]\n[inline: classification report]\n[inline: confusion matrix heatmap]"]
    end

    subgraph HFN["hybrid_predict_fn"]
        H["Wraps Hybrid_Pipeline:\naccepts X (np.ndarray)\nreturns [[P(normal), P(anomaly)], ...]"]
    end

    subgraph XAI["⑥ & ⑦ Explainability"]
        I["SHAP — 'the map of the terrain'\nKernelExplainer(hybrid_predict_fn, X_train_sample)\n  → global summary_plot bar chart  [inline]\n  → local waterfall/force plot per anomaly  [inline]\n  → top-N SHAP features per anomaly\n  (global + local view of Hybrid_Pipeline)"]
        J["LIME — 'street-level detail'\nLimeTabularExplainer(X_train, feature_names)\n  → explain_instance(x, hybrid_predict_fn)\n  → horizontal bar chart per anomaly  [inline]\n  → top-N LIME features per anomaly\n  (precise instance-level explanation)"]
    end

    subgraph LLM["⑧ LLM Reasoning"]
        K["build_prompt(anomaly_result, shap_exp, lime_exp)\nboto3 → AWS Bedrock Runtime\ninvoke_model(bedrock_model_id, prompt)\n─────────────────────────\nOutputs: ExplanationRecord[]\n[inline: transaction + narrative display]"]
    end

    L(["⑨ Results Summary\n─────────────────────────\nConsolidated DataFrame:\ntransaction_id | hybrid_score |\npredicted_label | llm_narrative"])

    B --> C
    C1 --> D
    C2 --> D
    D --> E
    D --> F
    E --> G
    F --> G
    G --> H
    H --> I
    H --> J
    I --> K
    J --> K
    K --> L
```

### Component Interaction Diagram

```mermaid
graph LR
    CFG[Config] -->|all params| ING_C[DataIngestor]
    CFG -->|all params| PRE_C[Preprocessor]
    CFG -->|contamination, n_estimators| ISO_C[IsolationForestModel]
    CFG -->|epochs, batch, patience| AE_C[AutoencoderModel]
    CFG -->|w_if, w_ae, threshold| HYB_C[HybridScorer]
    CFG -->|shap_top_n| SHAP_C[SHAPExplainer]
    CFG -->|lime_top_n| LIME_C[LIMEExplainer]
    CFG -->|model_id, top_k| LLM_C[LLMReasoner]

    ING_C -->|raw_df| PRE_C
    PRE_C -->|X_train, X_test, y_train, y_test| ISO_C
    PRE_C -->|X_train_normal, X_test| AE_C
    ISO_C -->|if_scores| HYB_C
    AE_C -->|ae_scores| HYB_C
    HYB_C -->|hybrid_predict_fn| SHAP_C
    HYB_C -->|hybrid_predict_fn| LIME_C
    HYB_C -->|AnomalyResult list| LLM_C
    SHAP_C -->|SHAPExplanation list| LLM_C
    LIME_C -->|LIMEExplanation list| LLM_C
    LLM_C -->|ExplanationRecord list| OUT[Inline Notebook Output]
```

---

## Components and Interfaces

### 1. DataIngestor

**Purpose:** Load or generate the transaction dataset based on `data_mode`.

```python
def load_or_generate(cfg: Config) -> pd.DataFrame:
    if cfg.data_mode == "synthetic":
        if Path("./data/transactions.csv").exists():
            return pd.read_csv("./data/transactions.csv")
        df = generate_transactions(cfg.n_transactions, cfg.anomaly_rate, cfg.random_seed)
        df.to_csv("./data/transactions.csv", index=False)
        return df
    elif cfg.data_mode == "external":
        if not Path(cfg.external_dataset_path).exists():
            raise FileNotFoundError(f"External dataset not found: {cfg.external_dataset_path}")
        df = pd.read_csv(cfg.external_dataset_path)
        _validate_columns(df)   # raises ValueError listing missing columns
        return df
```

**Required columns for external mode:** `amount`, `frequency`, `device_id`, `location`, `payment_channel`, `merchant_category`

**Synthetic anomaly injection strategy:**
- Normal: `amount` ~ LogNormal(μ=4.5, σ=0.8), `frequency` ~ Poisson(λ=3)
- Anomalous: `amount` ~ Uniform(500, 5000) OR `frequency` ~ Poisson(λ=20), randomly mixed

---

### 2. Preprocessor

**Purpose:** Clean, engineer features, encode categoricals, scale, and split.

```python
def preprocess(df: pd.DataFrame, cfg: Config) -> PreprocessedData:
    ...
```

**Steps:**
1. Drop rows with nulls in `amount`, `frequency`, `device_id`, `location`, `payment_channel`, `merchant_category` — log count
2. If `timestamp` column exists: engineer `hour_of_day`, `day_of_week`
3. One-hot encode all categorical columns (`merchant_id` if present, `merchant_category`, `device_id`, `location`, `payment_channel`) with `drop_first=True`
4. Train/test split (stratified on `is_anomaly` if present)
5. `StandardScaler` fit on `X_train`, transform both splits
6. Print shapes to output cell

---

### 3. IsolationForestModel

```python
def train_isolation_forest(
    X_train: np.ndarray,
    contamination: float = 0.05,
    n_estimators: int = 100,
    random_seed: int = 42,
) -> tuple[IsolationForest, np.ndarray]:
    ...
    # returns (fitted_model, score_samples(X_test))
```

Score convention: `score_samples()` returns negative average path length. More negative = more anomalous. HybridScorer inverts this.

---

### 4. AutoencoderModel

```python
class Autoencoder:
    def __init__(self, input_dim: int, cfg: Config): ...
    def fit(self, X_normal: np.ndarray) -> History: ...
    def reconstruction_error(self, X: np.ndarray) -> np.ndarray: ...
```

**Architecture** (D = number of features after encoding):

| Layer | Units | Activation |
|---|---|---|
| Input | D | — |
| Encoder 1 | D // 2 | ReLU |
| Encoder 2 | D // 4 | ReLU |
| Bottleneck | max(D // 8, 4) | ReLU |
| Decoder 1 | D // 4 | ReLU |
| Decoder 2 | D // 2 | ReLU |
| Output | D | Linear |

Linear output because StandardScaler output is unbounded. Training on normal-only samples forces high reconstruction error on anomalies.

---

### 5. HybridScorer + hybrid_predict_fn

```python
def compute_hybrid_scores(
    if_scores: np.ndarray,
    ae_scores: np.ndarray,
    w_if: float = 0.5,
    w_ae: float = 0.5,
    threshold: float = 0.5,
) -> list[AnomalyResult]:
    ...

def hybrid_predict_fn(X: np.ndarray) -> np.ndarray:
    """
    Wraps the full Hybrid_Pipeline.
    Returns shape (n_samples, 2): [[P(normal), P(anomaly)], ...]
    Used as the black-box function for both SHAP and LIME.
    """
    ...
```

**Hybrid scoring formula:**

```
Step 1 — Invert IF:      s_IF_inv(i) = -if_scores(i)
Step 2 — Normalise IF:   if_norm(i)  = (s_IF_inv(i) - min) / (max - min)
Step 3 — Normalise AE:   ae_norm(i)  = (ae_scores(i) - min) / (max - min)
Step 4 — Weighted avg:   hybrid(i)   = w_if · if_norm(i) + w_ae · ae_norm(i)
Step 5 — Classify:       label(i)    = 1 if hybrid(i) ≥ threshold else 0
```

Edge case: if `max == min` (constant score), set all normalised values to 0.0 and log a warning.

---

### 6. SHAPExplainer

**Role: "The map of the terrain"** — provides both global (across all test transactions) and local (per anomalous transaction) feature contributions targeting the full Hybrid_Pipeline. SHAP answers: *which features consistently drive the hybrid anomaly score, and why was this specific transaction flagged?*

**Key change from previous design:** SHAP now targets `hybrid_predict_fn` (the full Hybrid_Pipeline), not the Isolation Forest alone. This means SHAP values reflect each feature's contribution to the final combined anomaly score.

```python
def explain_shap(
    hybrid_predict_fn: Callable,
    X_train: np.ndarray,
    X_anomalies: np.ndarray,
    feature_names: list[str],
    top_n: int = 3,
) -> list[SHAPExplanation]:
    ...
```

**Implementation notes:**
- Use `shap.KernelExplainer(hybrid_predict_fn, shap.sample(X_train, 100))` — background sample of 100 rows for performance
- Global: `shap.summary_plot(shap_values, X_test, plot_type="bar")` — rendered inline
- Local per anomaly: `shap.waterfall_plot` or `shap.force_plot` — rendered inline
- Top-N: `np.argsort(np.abs(shap_values[i]))[-top_n:]`
- On failure for a sample: log error, set `shap_values = np.zeros(n_features)`

> **Note:** KernelExplainer is model-agnostic but slower than TreeExplainer. For a POC with ≤1000 test samples and a background of 100, runtime is acceptable (~1–3 min). If performance is a concern, reduce background sample size via Config.

---

### 7. LIMEExplainer

**Role: "Street-level detail"** — delivers precise instance-level explanations for each individual anomalous transaction. Where SHAP gives the map, LIME gives the exact turn-by-turn directions for a single transaction: *which specific feature values, in this exact transaction, pushed the hybrid score over the anomaly threshold?*

```python
def explain_lime(
    hybrid_predict_fn: Callable,
    X_train: np.ndarray,
    X_anomaly: np.ndarray,
    feature_names: list[str],
    top_n: int = 3,
) -> LIMEExplanation:
    ...
```

- `LimeTabularExplainer(X_train, feature_names=feature_names, mode="classification")`
- `explainer.explain_instance(X_anomaly, hybrid_predict_fn, num_features=top_n)`
- Bar chart rendered inline via `exp.as_pyplot_figure()`
- On failure: log error, set `top_features = []`

---

### 8. LLMReasoner

```python
def explain_with_llm(
    anomaly_results: list[AnomalyResult],
    shap_explanations: dict[str, SHAPExplanation],
    lime_explanations: dict[str, LIMEExplanation],
    cfg: Config,
) -> list[ExplanationRecord]:
    ...
```

Selects top-K by `hybrid_score`, builds prompt, calls Bedrock, displays inline.

---

## Data Models

### Transaction (raw schema)

| Field | Type | Description |
|---|---|---|
| `transaction_id` | `str` | UUID v4 (synthetic) or from CSV |
| `timestamp` | `datetime` | UTC (optional in external mode) |
| `amount` | `float` | Transaction amount in USD |
| `merchant_id` | `str` | e.g. `"M001"` – `"M020"` (optional in external) |
| `merchant_category` | `str` | e.g. `"food"`, `"electronics"`, `"travel"` |
| `device_id` | `str` | e.g. `"D001"` – `"D050"` |
| `location` | `str` | e.g. `"Jakarta"`, `"Surabaya"`, `"Bali"` |
| `payment_channel` | `str` | e.g. `"QR"`, `"NFC"`, `"online"` |
| `frequency` | `int` | Transactions by this card in last 24 h |
| `is_anomaly` | `int` | Ground-truth label: 0 = normal, 1 = anomaly |

### PreprocessedData (NamedTuple)

```python
class PreprocessedData(NamedTuple):
    X_train:      np.ndarray     # shape (n_train, n_features)
    X_test:       np.ndarray     # shape (n_test, n_features)
    y_train:      np.ndarray     # shape (n_train,)
    y_test:       np.ndarray     # shape (n_test,)
    scaler:       StandardScaler
    feature_names: list[str]
```

### AnomalyResult (dataclass)

```python
@dataclass
class AnomalyResult:
    transaction_id:  str
    if_score_raw:    float
    ae_score_raw:    float
    if_score_norm:   float
    ae_score_norm:   float
    hybrid_score:    float
    predicted_label: int
    true_label:      int
    features:        dict   # original unscaled values
```

### SHAPExplanation (dataclass)

```python
@dataclass
class SHAPExplanation:
    transaction_id: str
    shap_values:    np.ndarray
    top_features:   list[tuple[str, float]]
    base_value:     float
```

### LIMEExplanation (dataclass)

```python
@dataclass
class LIMEExplanation:
    transaction_id: str
    top_features:   list[tuple[str, float]]
    local_pred:     float
```

### ExplanationRecord (dataclass)

```python
@dataclass
class ExplanationRecord:
    transaction_id:   str
    anomaly_result:   AnomalyResult
    shap_explanation: SHAPExplanation
    lime_explanation: LIMEExplanation
    llm_narrative:    str
    prompt_sent:      str
```

---

## Prompt Template for AWS Bedrock

```
You are a financial fraud analyst reviewing QR-payment transactions.
A hybrid anomaly detection system (Isolation Forest + Autoencoder) has flagged
the following transaction as suspicious.

=== Transaction Details ===
Transaction ID   : {transaction_id}
Amount           : ${amount:.2f}
Merchant Category: {merchant_category}
Device ID        : {device_id}
Location         : {location}
Payment Channel  : {payment_channel}
Timestamp        : {timestamp}
Frequency (24h)  : {frequency}

=== Anomaly Scores ===
Isolation Forest score (normalised, 0=normal, 1=anomaly): {if_score_norm:.4f}
Autoencoder reconstruction error (normalised)           : {ae_score_norm:.4f}
Hybrid score                                            : {hybrid_score:.4f}

=== SHAP Top-{top_n} Contributing Features (Hybrid Pipeline) ===
{shap_feature_list}

=== LIME Top-{top_n} Contributing Features (Hybrid Pipeline) ===
{lime_feature_list}

=== Task ===
1. Explain in plain English why this transaction is suspicious, referencing the
   specific feature values and explainability scores above.
2. Identify the single most important risk factor.
3. Suggest one concrete follow-up action for a fraud analyst.

Keep your response concise (≤ 150 words).
```

Feature lists rendered as:
```
- amount: +0.42 (pushes toward anomaly)
- frequency: +0.31 (pushes toward anomaly)
- location: -0.08 (pushes toward normal)
```

---

## Configuration Parameters

```python
@dataclass
class Config:
    # Data Ingestion
    data_mode:             str   = "synthetic"   # "synthetic" or "external"
    external_dataset_path: str   = "./data/external_transactions.csv"

    # Simulation (synthetic mode only)
    n_transactions:        int   = 1000
    anomaly_rate:          float = 0.05
    random_seed:           int   = 42

    # Preprocessing
    test_size:             float = 0.20

    # Isolation Forest
    if_contamination:      float = 0.05
    if_n_estimators:       int   = 100

    # Autoencoder
    ae_epochs:             int   = 50
    ae_batch_size:         int   = 32
    ae_patience:           int   = 10

    # Hybrid Scoring
    w_if:                  float = 0.5
    w_ae:                  float = 0.5
    hybrid_threshold:      float = 0.5

    # Explainability
    shap_top_n:            int   = 3
    lime_top_n:            int   = 3
    shap_background_size:  int   = 100   # KernelExplainer background sample size

    # LLM
    bedrock_model_id:      str   = "anthropic.claude-3-sonnet-20240229-v1:0"
    llm_top_k:             int   = 5

cfg = Config()
```

---

## Error Handling

| Stage | Condition | Handling |
|---|---|---|
| Data Ingestion | External CSV not found | `FileNotFoundError` with path — halt |
| Data Ingestion | Required columns missing | `ValueError` listing missing columns — halt |
| Preprocessing | Missing values in required fields | Drop rows, log count with `warnings.warn` |
| Preprocessing | All rows dropped | `ValueError("Dataset empty after cleaning")` — halt |
| Preprocessing | Split produces < 10 samples in either set | `ValueError` with descriptive message — halt |
| Autoencoder | No normal samples in training split | `ValueError("No normal samples for Autoencoder training")` — halt |
| Autoencoder | Early stopping before epoch 5 | Log warning; continue with best weights |
| Hybrid Scoring | `max == min` in normalisation | Set all normalised values to 0.0; log warning |
| Hybrid Scoring | `w_if + w_ae != 1.0` | `ValueError("Weights must sum to 1.0")` — halt |
| SHAP | Computation fails for a sample | Log error; set `shap_values = np.zeros(n_features)` |
| LIME | Computation fails for a sample | Log error; set `top_features = []` |
| Bedrock | `NoCredentialsError` | `llm_narrative = "LLM unavailable: AWS credentials not configured"` — continue |
| Bedrock | `ClientError` (throttle/unavailable) | Retry once after 2s; on 2nd failure set narrative to error — continue |
| Bedrock | Response parse error | `llm_narrative = "LLM unavailable: response parse error"` — continue |
| Bedrock | Network timeout | `llm_narrative = "LLM unavailable: network timeout"` — continue |

All Bedrock errors are **non-fatal** — the notebook continues and displays all other results.

---

## Correctness Properties

### Property 1: Anomaly injection rate is within bounds
For any call to `generate_transactions(n, anomaly_rate)`, the fraction of rows where `is_anomaly == 1` shall be within ±1% of `anomaly_rate`. **Validates: Req 1.2, 1.8**

### Property 2: Scaler fit-on-train isolation
The `StandardScaler` fitted on `X_train` shall produce mean ≈ 0 and std ≈ 1 on `X_train`; the same fitted scaler (not re-fitted) shall transform `X_test`. **Validates: Req 2.4**

### Property 3: Hybrid scores bounded in [0, 1]
For any IF and AE score arrays, after normalisation and weighted averaging, every `hybrid_score` shall lie in [0, 1]. **Validates: Req 5.2, 5.3**

### Property 4: Hybrid score weight constraint
For any `w_if + w_ae == 1.0`, the formula shall produce `hybrid == w_if * if_norm + w_ae * ae_norm` element-wise. **Validates: Req 5.3**

### Property 5: SHAP top-N feature count
For any `top_n ≥ 1`, `SHAPExplanation.top_features` shall contain exactly `min(top_n, n_features)` entries. **Validates: Req 6.5**

### Property 6: LIME top-N feature count
For any `top_n ≥ 1`, `LIMEExplanation.top_features` shall contain exactly `min(top_n, n_features)` entries. **Validates: Req 7.4**

### Property 7: Autoencoder reconstruction error is non-negative
For any input sample, MSE reconstruction error shall be ≥ 0. **Validates: Req 4.2**

### Property 8: Normal-only Autoencoder training
Mean reconstruction error on normal training samples shall be strictly lower than mean on anomalous test samples. **Validates: Req 4.1**
