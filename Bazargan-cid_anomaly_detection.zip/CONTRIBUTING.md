# Contributing to Bazargan-CID

Thank you for your interest in contributing! Here's how you can help:

## Getting Started

1. Fork the repository
2. Clone your fork: `git clone https://github.com/YOUR_USERNAME/Bazargan-cid.git`
3. Create a branch: `git checkout -b feature/your-feature-name`
4. Install dependencies: `pip install -r requirements.txt`

## Development Workflow

1. Make your changes
2. Test your changes: `python test_notebook_imports.py`
3. Commit with clear messages: `git commit -m "Add feature: description"`
4. Push to your fork: `git push origin feature/your-feature-name`
5. Create a Pull Request

## Code Style

- Follow PEP 8
- Use type hints where possible
- Add docstrings to functions and classes
- Keep notebook cells focused and well-documented

## Testing

Before submitting a PR:
- Ensure all imports work: `python test_notebook_imports.py`
- Run the notebook end-to-end
- Check for any warnings or errors

## Issues

- Use GitHub Issues to report bugs
- Provide clear descriptions and reproduction steps
- Include environment details (Python version, OS, etc.)

## Questions?

Feel free to open an issue or discussion for questions!
